Name: Shreyas Rai
PRN: 21070126088
Batch: AIML B1

OS: Mac OS 12 Monterey
java Version: 19.0.1 2022-10-18
Java(TM) SE Runtime Environment (build 19.0.1+10-21)
Java HotSpot(TM) 64-Bit Server VM (build 19.0.1+10-21, mixed mode, sharing)

Title: PIJ Lab Assignment-1 

Problem Statement:
Implement a simple menu driven calculator in java to implement
add, sub, multiply, div, square root, power, mean, variance. Implement a separate
Calculator class to include all related function inside that class.

The java program consists of 3 distinct classes, i.e. Main.java, Calculator.java & UserInput.java.

1.Main.java:

The Main class contains the psvm function which has the switch case program of function calls that can be performed by the user within the do while loop. The User can enter the operation to perform, give the required data and get the desired output and can even perform multiple operations using the do while program.

2.Calculator.java:

The Calculator class contains all the function definitions of the mathematical operations that we are making available for the user to perform.

3.UserInput.java

The UserInput class contains functions to take data input from the user and to print the data in an array.


Functions from both the Calculator class and userInput class are called in the psvm function using the objects of their respective classes.